﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Pclasses
{
    abstract internal class Empregado
    {
       //posso alterar a classe de internal para outras
       //um exemplo é o protect, que repassa a informaçao para as classes filhas
       
        private int matricula;//atributo
        private string nomeEmpregado;
        private DateTime dataEntradaEmpresa;

        //private=disponivel somente dentro da classe que a declarou

        public int Matricula //propriedade
        {  
            get { return matricula; }
            set { matricula = value; } 
        }

        public string NomeEmpregado
        {   
            get { return nomeEmpregado; } 
            set { nomeEmpregado = value;  }
        }
        public DateTime DataEntradaEmpresa
        {
            get { return dataEntradaEmpresa; }
            set { dataEntradaEmpresa = value; }
        }
        //metodo sao acoes/comportamentos
        //virtual-->pode ser sobreescrito
        public virtual int TempoTrabalho()
        {
            //representa um intervalo de tempo
            TimeSpan span =
            DateTime.Today.Subtract(DataEntradaEmpresa);
            return (span.Days);
        }
        //deve ser implementado
        //Derived classes must implement this
        //classe abstrata nao permite que voce cire objetos dela
        //logo, toda vez que vc não quer isso, vc limita desse jeito

        public abstract double SalarioBruto();


        public Empregado()
        {
            System.Windows.Forms.MessageBox.Show("aqui é empregado");
        }
        public Empregado (int mat, string nome, DateTime datax)
        {
            matricula = mat;
            NomeEmpregado = nome;
            dataEntradaEmpresa = datax;


        }
    }
}
