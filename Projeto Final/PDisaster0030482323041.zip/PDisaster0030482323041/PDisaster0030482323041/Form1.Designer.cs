﻿namespace PDisaster0030482323041
{
    partial class frmPrincipal
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.mnuPrincipal = new System.Windows.Forms.MenuStrip();
            this.OutrosCadastros = new System.Windows.Forms.ToolStripMenuItem();
            this.CadastroCidades = new System.Windows.Forms.ToolStripMenuItem();
            this.CadastroTipoDeEventos = new System.Windows.Forms.ToolStripMenuItem();
            this.CadastroEventos = new System.Windows.Forms.ToolStripMenuItem();
            this.Sobre = new System.Windows.Forms.ToolStripMenuItem();
            this.sairToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuPrincipal.SuspendLayout();
            this.SuspendLayout();
            // 
            // mnuPrincipal
            // 
            this.mnuPrincipal.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.mnuPrincipal.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.OutrosCadastros,
            this.CadastroEventos,
            this.Sobre,
            this.sairToolStripMenuItem});
            this.mnuPrincipal.Location = new System.Drawing.Point(0, 0);
            this.mnuPrincipal.Name = "mnuPrincipal";
            this.mnuPrincipal.Size = new System.Drawing.Size(978, 28);
            this.mnuPrincipal.TabIndex = 0;
            this.mnuPrincipal.Text = "menuStrip1";
            // 
            // OutrosCadastros
            // 
            this.OutrosCadastros.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CadastroCidades,
            this.CadastroTipoDeEventos});
            this.OutrosCadastros.Name = "OutrosCadastros";
            this.OutrosCadastros.Size = new System.Drawing.Size(136, 24);
            this.OutrosCadastros.Text = "Outros Cadastros";
            // 
            // CadastroCidades
            // 
            this.CadastroCidades.Name = "CadastroCidades";
            this.CadastroCidades.Size = new System.Drawing.Size(267, 26);
            this.CadastroCidades.Text = "Cadastro Cidades";
            this.CadastroCidades.Click += new System.EventHandler(this.CadastroCidades_Click);
            // 
            // CadastroTipoDeEventos
            // 
            this.CadastroTipoDeEventos.Name = "CadastroTipoDeEventos";
            this.CadastroTipoDeEventos.Size = new System.Drawing.Size(267, 26);
            this.CadastroTipoDeEventos.Text = "Cadastro Tipos de Eventos";
            this.CadastroTipoDeEventos.Click += new System.EventHandler(this.CadastroTipoDeEventos_Click);
            // 
            // CadastroEventos
            // 
            this.CadastroEventos.Name = "CadastroEventos";
            this.CadastroEventos.Size = new System.Drawing.Size(137, 24);
            this.CadastroEventos.Text = "Cadastro Eventos";
            this.CadastroEventos.Click += new System.EventHandler(this.CadastroEventos_Click);
            // 
            // Sobre
            // 
            this.Sobre.Name = "Sobre";
            this.Sobre.Size = new System.Drawing.Size(62, 24);
            this.Sobre.Text = "Sobre";
            this.Sobre.Click += new System.EventHandler(this.sobreToolStripMenuItem_Click);
            // 
            // sairToolStripMenuItem
            // 
            this.sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            this.sairToolStripMenuItem.Size = new System.Drawing.Size(48, 24);
            this.sairToolStripMenuItem.Text = "Sair";
            this.sairToolStripMenuItem.Click += new System.EventHandler(this.sairToolStripMenuItem_Click);
            // 
            // frmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(978, 501);
            this.Controls.Add(this.mnuPrincipal);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.mnuPrincipal;
            this.Name = "frmPrincipal";
            this.Text = "CADASTRO DE EVENTOS NATURAIS";
            this.Load += new System.EventHandler(this.frmPrincipal_Load);
            this.mnuPrincipal.ResumeLayout(false);
            this.mnuPrincipal.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mnuPrincipal;
        private System.Windows.Forms.ToolStripMenuItem OutrosCadastros;
        private System.Windows.Forms.ToolStripMenuItem CadastroCidades;
        private System.Windows.Forms.ToolStripMenuItem CadastroTipoDeEventos;
        private System.Windows.Forms.ToolStripMenuItem CadastroEventos;
        private System.Windows.Forms.ToolStripMenuItem Sobre;
        private System.Windows.Forms.ToolStripMenuItem sairToolStripMenuItem;
    }
}

