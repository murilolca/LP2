﻿namespace Calc.lp2
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.textResultado = new System.Windows.Forms.TextBox();
            this.Textnumero1 = new System.Windows.Forms.TextBox();
            this.Textnumero2 = new System.Windows.Forms.TextBox();
            this.BtnAD = new System.Windows.Forms.Button();
            this.Btnmulti = new System.Windows.Forms.Button();
            this.BtnDiv = new System.Windows.Forms.Button();
            this.BtnSub = new System.Windows.Forms.Button();
            this.BtnLimpar = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.lblNumero1 = new System.Windows.Forms.Label();
            this.Lblnumeo2 = new System.Windows.Forms.Label();
            this.LblResultado = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textResultado
            // 
            this.textResultado.Enabled = false;
            this.textResultado.Location = new System.Drawing.Point(297, 209);
            this.textResultado.Name = "textResultado";
            this.textResultado.Size = new System.Drawing.Size(100, 26);
            this.textResultado.TabIndex = 0;
            // 
            // Textnumero1
            // 
            this.Textnumero1.Location = new System.Drawing.Point(297, 72);
            this.Textnumero1.Name = "Textnumero1";
            this.Textnumero1.Size = new System.Drawing.Size(100, 26);
            this.Textnumero1.TabIndex = 1;
            this.Textnumero1.Validated += new System.EventHandler(this.Textnumero1_Validated);
            // 
            // Textnumero2
            // 
            this.Textnumero2.Location = new System.Drawing.Point(297, 139);
            this.Textnumero2.Name = "Textnumero2";
            this.Textnumero2.Size = new System.Drawing.Size(100, 26);
            this.Textnumero2.TabIndex = 2;
            this.Textnumero2.Validated += new System.EventHandler(this.Textnumero2_Validated);
            // 
            // BtnAD
            // 
            this.BtnAD.Location = new System.Drawing.Point(190, 306);
            this.BtnAD.Name = "BtnAD";
            this.BtnAD.Size = new System.Drawing.Size(75, 91);
            this.BtnAD.TabIndex = 3;
            this.BtnAD.Text = "ADD";
            this.BtnAD.UseVisualStyleBackColor = true;
            this.BtnAD.Click += new System.EventHandler(this.BtnAD_Click);
            // 
            // Btnmulti
            // 
            this.Btnmulti.Location = new System.Drawing.Point(190, 406);
            this.Btnmulti.Name = "Btnmulti";
            this.Btnmulti.Size = new System.Drawing.Size(75, 110);
            this.Btnmulti.TabIndex = 4;
            this.Btnmulti.Text = "Multi";
            this.Btnmulti.UseVisualStyleBackColor = true;
            this.Btnmulti.Click += new System.EventHandler(this.Btnmulti_Click);
            // 
            // BtnDiv
            // 
            this.BtnDiv.Location = new System.Drawing.Point(287, 306);
            this.BtnDiv.Name = "BtnDiv";
            this.BtnDiv.Size = new System.Drawing.Size(78, 95);
            this.BtnDiv.TabIndex = 5;
            this.BtnDiv.Text = "Div";
            this.BtnDiv.UseVisualStyleBackColor = true;
            this.BtnDiv.Click += new System.EventHandler(this.BtnDiv_Click);
            // 
            // BtnSub
            // 
            this.BtnSub.Location = new System.Drawing.Point(287, 406);
            this.BtnSub.Name = "BtnSub";
            this.BtnSub.Size = new System.Drawing.Size(78, 110);
            this.BtnSub.TabIndex = 6;
            this.BtnSub.Text = "Sub";
            this.BtnSub.UseVisualStyleBackColor = true;
            this.BtnSub.Click += new System.EventHandler(this.BtnSub_Click);
            // 
            // BtnLimpar
            // 
            this.BtnLimpar.Location = new System.Drawing.Point(391, 306);
            this.BtnLimpar.Name = "BtnLimpar";
            this.BtnLimpar.Size = new System.Drawing.Size(75, 91);
            this.BtnLimpar.TabIndex = 8;
            this.BtnLimpar.Text = "Limpar";
            this.BtnLimpar.UseVisualStyleBackColor = true;
            this.BtnLimpar.Click += new System.EventHandler(this.BtnLimpar_Click);
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(391, 406);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(75, 111);
            this.btnSair.TabIndex = 9;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // lblNumero1
            // 
            this.lblNumero1.AutoSize = true;
            this.lblNumero1.Location = new System.Drawing.Point(191, 72);
            this.lblNumero1.Name = "lblNumero1";
            this.lblNumero1.Size = new System.Drawing.Size(74, 20);
            this.lblNumero1.TabIndex = 10;
            this.lblNumero1.Text = "Numero1";
            // 
            // Lblnumeo2
            // 
            this.Lblnumeo2.AutoSize = true;
            this.Lblnumeo2.Location = new System.Drawing.Point(191, 142);
            this.Lblnumeo2.Name = "Lblnumeo2";
            this.Lblnumeo2.Size = new System.Drawing.Size(74, 20);
            this.Lblnumeo2.TabIndex = 11;
            this.Lblnumeo2.Text = "Numero2";
            // 
            // LblResultado
            // 
            this.LblResultado.AutoSize = true;
            this.LblResultado.Location = new System.Drawing.Point(183, 209);
            this.LblResultado.Name = "LblResultado";
            this.LblResultado.Size = new System.Drawing.Size(82, 20);
            this.LblResultado.TabIndex = 12;
            this.LblResultado.Text = "Resultado";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1241, 631);
            this.Controls.Add(this.LblResultado);
            this.Controls.Add(this.Lblnumeo2);
            this.Controls.Add(this.lblNumero1);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.BtnLimpar);
            this.Controls.Add(this.BtnSub);
            this.Controls.Add(this.BtnDiv);
            this.Controls.Add(this.Btnmulti);
            this.Controls.Add(this.BtnAD);
            this.Controls.Add(this.Textnumero2);
            this.Controls.Add(this.Textnumero1);
            this.Controls.Add(this.textResultado);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textResultado;
        private System.Windows.Forms.TextBox Textnumero1;
        private System.Windows.Forms.TextBox Textnumero2;
        private System.Windows.Forms.Button BtnAD;
        private System.Windows.Forms.Button Btnmulti;
        private System.Windows.Forms.Button BtnDiv;
        private System.Windows.Forms.Button BtnSub;
        private System.Windows.Forms.Button BtnLimpar;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Label lblNumero1;
        private System.Windows.Forms.Label Lblnumeo2;
        private System.Windows.Forms.Label LblResultado;
    }
}

