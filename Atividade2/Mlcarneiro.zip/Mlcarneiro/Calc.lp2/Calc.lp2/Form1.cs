﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calc.lp2
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {

        }

        private void Textnumero2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(Textnumero2.Text, out numero2))
            {
                MessageBox.Show("Numero 2 invalido!");
                Textnumero2.Focus();
            }
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            Textnumero1.Text="";
            Textnumero2.Text=string.Empty;
            textResultado.Text=null;

        }
    

        private void BtnAD_Click(object sender, EventArgs e)
        {
            resultado= numero1 + numero2;
            textResultado.Text= resultado.ToString();
        }

        private void BtnDiv_Click(object sender, EventArgs e)
        {
            if (numero2 == 0)
            {
                MessageBox.Show("Este valor é invalido");
                Textnumero2.Focus();
               
            }
            else
            {
                resultado = numero1 / numero2;
                textResultado.Text = resultado.ToString();
            }
          
        }

        private void Btnmulti_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            textResultado.Text = resultado.ToString();
        }

        private void BtnSub_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            textResultado.Text = resultado.ToString();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Voce realmente deseja sair?",
                    "saida",MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question)==
                DialogResult.Yes)
                Close();    
        }

        private void Textnumero1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(Textnumero1.Text, out numero1))
            {
                MessageBox.Show("Numero 1 invalido!");
                Textnumero1.Focus();

            }
        }
    }
}
