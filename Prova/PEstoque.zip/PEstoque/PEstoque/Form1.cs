﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PEstoque
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            int add1 = 0, add3 = 0;
            int[] add2 = new int[11];
            int[,] vetorM = new int [11, 4];
            String aux;

            for (int i = 0; i < 11; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    aux = Interaction.InputBox($"Insira o numero do produto da semana{j + 1}", "Entrada de dados");
                    if (!int.TryParse(aux, out vetorM[i, j]) || vetorM[i, j] < 0)
                    {
                        MessageBox.Show("O número inserido é inválido!");
                        j--;
                    }

                }
            }
            for (int i = 0; i < 11; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    add1 += vetorM[i, j];
                }
                add2[i] = add1;
                add3 += add2[i];
                add1 = 0;
            }
            for (int i = 0; i < 11; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    aux = "";
                    aux += $"Total Entradas do Produto:{i + 1} Semana {j + 1} -{vetorM[i, j]}";
                    listProd.Items.Add(aux);
                }
                aux = "";
                aux += $">>Total Entradas do Produto: {i + 1}                       {add2[i]}";
                listProd.Items.Add(aux);
                aux = "";
                aux += $"-----------------------------------------------------------------";
                listProd.Items.Add(aux);
            }
            aux = "";
            aux += $">>Total Geral Entradas:                          {add3}";
            listProd.Items.Add(aux);
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            listProd.Items.Clear();
        }
    }
}
